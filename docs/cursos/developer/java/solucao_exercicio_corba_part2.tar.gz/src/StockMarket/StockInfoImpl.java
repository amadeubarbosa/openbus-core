package StockMarket;

/**
 * Implementa o valuetype StockInfo.
 * 
 * @author Tecgraf
 */
public class StockInfoImpl extends StockInfo {

  /**
   * Construtor.
   */
  public StockInfoImpl() {
  }

  /**
   * Construtor.
   * 
   * @param name o nome da a��o (s�mbolo)
   * @param value o valor da a��o
   */
  public StockInfoImpl(String name, float value) {
    this.name = name;
    this.value = value;
  }

  @Override
  public String _toString() {
    return "A a��o " + name + " possui um valor " + value;
  }

}
