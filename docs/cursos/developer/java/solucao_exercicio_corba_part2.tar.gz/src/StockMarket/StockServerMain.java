package StockMarket;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Properties;

import org.omg.CORBA.ORB;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.Servant;

/**
 * Exemplo de um servidor que registra um objeto CORBA para a IDL
 * StockMarket::StockServer
 */
public class StockServerMain {

  /**
   * Programa principal. Recebe como argumento o nome do arquivo local onde ser�
   * gravado IOR para o objeto CORBA
   * 
   * @param args um array com um �nico argumento que deve ser o nome de um
   *        arquivo
   */
  public static void main(String args[]) {

    try {

      /*
       * As propriedades que informam o uso do JacORB como ORB.
       */
      Properties orbProps = new Properties();
      orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
      orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
        "org.jacorb.orb.ORBSingleton");

      // Inicializa o ORB
      ORB orb = ORB.init(args, orbProps);

      // Cria o Servant StockServerImpl que implementa a IDL
      Servant stockServer = new StockServerImpl();

      // Uma outra forma de criar o Servant � usando delega��o, 
      // com o mecanismo de Tie
      // Servant stockServer = new StockServerPOATie(new StockServerImpl());

      // Obt�m uma refer�ncia para o POA e registra o Servant nesse POA
      POA poa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
      poa.the_POAManager().activate();
      org.omg.CORBA.Object o = poa.servant_to_reference(stockServer);

      // Escreve no arquivo a refer�ncia para o objeto CORBA
      PrintWriter ps = new PrintWriter(new FileOutputStream(new File(args[0])));
      ps.println(orb.object_to_string(o));
      ps.close();

      // Bloqueia a thread corrente at� o ORB finalizar
      orb.run();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}
