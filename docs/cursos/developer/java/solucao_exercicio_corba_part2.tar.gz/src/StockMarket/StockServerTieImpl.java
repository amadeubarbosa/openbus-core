package StockMarket;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * StockServerImpl implementa a interface IDL StockServer usando o mecanismo de
 * delega��o com Tie
 */
public class StockServerTieImpl implements StockServerOperations {

  /** As a��es com seus respectivos valores */
  private Map<String, Float> myStock;

  /** Caracteres a partir dos quais os nomes para StockSymbol s�o gerados */
  private static char ourCharacters[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G',
      'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
      'V', 'W', 'X', 'Y', 'Z' };

  /**
   * Construtor
   */
  public StockServerTieImpl() {
    myStock = new HashMap<String, Float>();
    // Inicializa as a��es com nomes e valores 
    // atribu�dos randomicamente
    for (int i = 0; i < 10; i++) {
      // Gera uma string com 4 caracteres rand�micos.
      StringBuffer stockSymbol = new StringBuffer("    ");
      for (int j = 0; j < 4; j++) {
        stockSymbol.setCharAt(j, ourCharacters[(int) (Math.random() * 26f)]);
      }
      myStock.put(stockSymbol.toString(), new Float(Math.random() * 100f));
    }

    // Exibe as a��es criados acima.
    System.out.println("A��es do mercado criadas:");
    Set<String> symbols = myStock.keySet();
    Iterator<String> itr = symbols.iterator();
    while (itr.hasNext()) {
      String symbol = itr.next();
      System.out.println(symbol + ": " + myStock.get(symbol));
    }
    System.out.println();
  }

  /**
   * Retorna o valor corrente a determinada a��o do mercado, dado o s�mbolo que
   * a representa.
   */
  @Override
  public float getStockValue(String symbol) {
    // Tenta encontrar o simbolo
    if (myStock.containsKey(symbol)) {
      // Simbolo encontrado; retorna seu valor
      return myStock.get(symbol);
    }
    else {
      // Simbolo n�o foi encontrado
      return 0f;
    }
  }

  /**
   * Retorna a sequ�ncia com todos os s�mbolos que definem as a��es de mercado
   * mantidos por esse StockServer.
   */
  @Override
  public String[] getStockSymbols() {
    return myStock.keySet().toArray(new String[0]);
  }

  /**
   * Retorna a sequ�ncia com as informa��es sobre as a��es do mercado mantidos
   * por esse StockServer.
   */
  @Override
  public StockInfo[] getStockInfo() {
    List<StockInfo> stockInfoList = new ArrayList<StockInfo>();
    for (String name : myStock.keySet()) {
      float value = myStock.get(name);
      stockInfoList.add(new StockInfoImpl(name, value));
    }
    return stockInfoList.toArray(new StockInfo[0]);
  }
}
