package StockMarket;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;

import org.omg.CORBA.UserException;

import scs.core.FacetDescription;
import scs.core.IComponent;
import scs.core.IMetaInterface;
import scs.core.IMetaInterfaceHelper;
import scs.core.IReceptacles;
import scs.core.IReceptaclesHelper;
import tecgraf.openbus.Openbus;
import tecgraf.openbus.core.v1_05.registry_service.IRegistryService;
import tecgraf.openbus.core.v1_05.registry_service.ServiceOffer;
import tecgraf.openbus.exception.OpenbusAlreadyInitializedException;
import tecgraf.openbus.exception.RSUnavailableException;
import tecgraf.openbus.util.Log;

/**
 * Exemplo de um cliente que conecta todos os componentes que implementam a
 * faceta ExchangePrinter com o componente StockSeller.
 * 
 * @author Tecgraf PUC-Rio
 */
public class StockMarketConfigurator {
  /**
   * Nome do arquivo que possui as propriedades para execu��o do cliente.
   */
  public static final String CLIENT_PROP_FILE = "/client.properties";

  /**
   * Executa as etapas de constru��o do um cliente que utiliza o openbus para
   * procurar por uma oferta de um servi�o que oferece a faceta StockServer.
   * 
   * @param args os par�metros passados pela linha de comando
   * @throws StockMarketConfiguratorException se ocorrer algum erro durante a
   *         execu��o do exemplo
   */
  private void run(String[] args) throws StockMarketConfiguratorException {
    Properties props = loadProperties();
    Openbus bus = initOpenbus(args, props);
    IRegistryService registryService = connectWithOpenBus(props);
    connect(registryService);
    bus.disconnect();
  }

  /**
   * Carrega as propriedades do exemplo StockServer.
   * 
   * @return as propriedades carregadas a partir do arquivo
   *         {@link #CLIENT_PROP_FILE}
   * @throws StockMarketConfiguratorException se houver um erro durante a carga
   *         das propriedades
   */
  private Properties loadProperties() throws StockMarketConfiguratorException {
    Properties props = new Properties();
    InputStream in =
      StockServerOpenbus.class.getResourceAsStream(CLIENT_PROP_FILE);
    if (in != null) {
      try {
        props.load(in);
      }
      catch (IOException e) {
        throw new StockMarketConfiguratorException(
          "Erro ao carregar o arquivo de propriedades " + CLIENT_PROP_FILE, e);
      }
      finally {
        try {
          in.close();
        }
        catch (IOException e) {
          throw new StockMarketConfiguratorException(
            "Erro ao fechar o arquivo de propriedades " + CLIENT_PROP_FILE, e);
        }
      }
      return props;
    }
    else {
      throw new StockMarketConfiguratorException(
        "Erro ao abrir o arquivo de propriedades " + CLIENT_PROP_FILE);
    }
  }

  /**
   * Faz a inicializa��o do Openbus. Configura as propriedades do ORB com os
   * argumentos passados na linha de comando e com as propriedades para o uso do
   * Jacorb.
   * 
   * @param args argumentos passados pela linha de comando
   * @param props propriedades do arquivo
   * @return o openbus iniciado
   * @throws StockMarketConfiguratorException se ocorrer um erro durante a
   *         inicializa��o do Openbus.
   */
  private Openbus initOpenbus(String[] args, Properties props)
    throws StockMarketConfiguratorException {
    String host = props.getProperty("host.name");
    String portString = props.getProperty("host.port");
    int port = Integer.valueOf(portString);
    String ip = props.getProperty("OAIAddr");

    Log.setLogsLevel(Level.WARNING);
    Properties orbProps = new Properties();
    orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
    orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
      "org.jacorb.orb.ORBSingleton");
    if (ip != null) {
      orbProps.setProperty("OAIAddr", ip);
    }
    Openbus bus = Openbus.getInstance();

    try {
      bus.init(args, orbProps, host, port);
      return bus;
    }
    catch (OpenbusAlreadyInitializedException e) {
      throw new StockMarketConfiguratorException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
    catch (UserException e) {
      throw new StockMarketConfiguratorException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
  }

  /**
   * Obt�m o servi�o de registro resultado da conex�o com o Openbus.
   * 
   * @param props as propriedades que possuem as informa��es com o nome da
   *        entidade do certificado, o nome do arquivo com a chave privada
   *        correspondente e o nome do arquivo com o certificado p�blico do
   *        servi�o de acesso.
   * @return a refer�ncia para o servi�o de registro
   * 
   * @throws StockMarketConfiguratorException se houver algum erro durante a
   *         conex�o com o servi�o de acesso do openbus.
   */
  private IRegistryService connectWithOpenBus(Properties props)
    throws StockMarketConfiguratorException {
    String userLogin = props.getProperty("login");
    String userPassword = props.getProperty("password");
    Openbus bus = Openbus.getInstance();
    try {
      IRegistryService registryService = bus.connect(userLogin, userPassword);
      if (registryService == null) {
        throw new RSUnavailableException();
      }
      System.out.println("Stock Client conectado.");
      return registryService;
    }
    catch (Exception e) {
      throw new StockMarketConfiguratorException(
        "Erro ao fazer a conex�o com o Openbus", e);
    }
  }

  /**
   * Conecta todos os componentes que implementam a faceta ExchangePrinter com o
   * componente StockSeller.
   * 
   * @param registryService o servi�o de registro que possui a componente
   *        registrado
   */
  private void connect(IRegistryService registryService) {
    // Obt�m a refer�ncia para o component StockSeller
    ServiceOffer[] servicesOffers =
      registryService.find(new String[] { "StockServer" });
    ServiceOffer serviceOffer = servicesOffers[0];
    IComponent component = serviceOffer.member;

    // Obt�m a refer�ncia para IReceptacles do StockSeller
    IReceptacles irStockSeller =
      IReceptaclesHelper.narrow(component.getFacet(IReceptaclesHelper.id()));

    // Conecta todas as componentes que implementam a faceta  ExchangePrinter
    // com o componente StockSeller
    servicesOffers =
      registryService.find(new String[] { ExchangePrinterHelper.id() });
    for (ServiceOffer offer : servicesOffers) {
      try {
        IMetaInterface metaInterface =
          IMetaInterfaceHelper.narrow(offer.member
            .getFacet(IMetaInterfaceHelper.id()));
        FacetDescription[] facetDescArray = metaInterface.getFacets();
        for (FacetDescription facet : facetDescArray) {
          if (facet.interface_name.equals(ExchangePrinterHelper.id())) {
            irStockSeller.connect("ExchangePrinter", ExchangePrinterHelper
              .narrow(offer.member.getFacetByName(facet.name)));
          }
        }
        System.out.println("Component conectado");
      }
      catch (Exception e) {
        e.printStackTrace();
      }
    }
  }

  /**
   * Programa principal que executa o cliente.
   * 
   * @param args os argumentos passados pela linha de comando
   */
  public static void main(String[] args) {
    StockMarketConfigurator demo = new StockMarketConfigurator();
    try {
      demo.run(args);
    }
    catch (Throwable e) {
      e.printStackTrace();
    }
  }

  /**
   * Exce��o usada no exemplo para reportar os erros durante a execu��o.
   */
  class StockMarketConfiguratorException extends Exception {
    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     */
    public StockMarketConfiguratorException(String msg) {
      super(msg);
    }

    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     * @param t a causa do erro
     */
    public StockMarketConfiguratorException(String msg, Throwable t) {
      super(msg, t);
    }
  }
}
