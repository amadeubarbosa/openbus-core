package StockMarket;

import java.util.HashMap;
import java.util.Map;

import scs.core.ComponentId;
import scs.core.servant.ComponentBuilder;
import scs.core.servant.ComponentContextImpl;

/**
 * Contexto compartilhado pelas facetas do componente StockSeller.
 */
public class StockSellerContextImpl extends ComponentContextImpl {
  /** As a��es com seus respectivos valores */
  private Map<String, Float> myStock;

  /** Caracteres a partir dos quais os nomes para StockSymbol s�o gerados */
  private static char ourCharacters[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G',
      'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
      'V', 'W', 'X', 'Y', 'Z' };

  /**
   * Construtor.
   * 
   * @param builder o objeto respons�vel pela instancia��o do componente.
   * @param componentId o identificador do componente.
   */
  public StockSellerContextImpl(ComponentBuilder builder,
    ComponentId componentId) {
    super(builder, componentId);
    myStock = new HashMap<String, Float>();
    // Inicializa as a��es com nomes e valores 
    // atribu�dos randomicamente
    for (int i = 0; i < 10; i++) {
      // Gera uma string com 4 caracteres rand�micos.
      StringBuffer stockSymbol = new StringBuffer("    ");
      for (int j = 0; j < 4; j++) {
        stockSymbol.setCharAt(j, ourCharacters[(int) (Math.random() * 26f)]);
      }
      myStock.put(stockSymbol.toString(), new Float(Math.random() * 100f));
    }
  }

  /**
   * Verifica se existe uma a��o com o s�mbolo especificado.
   * 
   * @param symbol o s�mbolo procurado
   * @return {@code true} se o s�mbolo foi encontrado ou {@code false} caso
   *         contr�rio
   */
  public synchronized boolean containsStockSymbol(String symbol) {
    return myStock.containsKey(symbol);
  }

  /**
   * Obt�m o valor de uma determinada a��o, dado o seu s�mbolo.
   * 
   * @param symbol o s�mbolo
   * @return o valor da a��o
   */
  public synchronized float getStockValue(String symbol) {
    return myStock.get(symbol);
  }

  /**
   * Obt�m todos os s�mbolos de a��es.
   * 
   * @return o array com todos os s�mbolos de a��es
   */
  public synchronized String[] getAllSymbols() {
    return myStock.keySet().toArray(new String[0]);
  }

  /**
   * Decrementa o valor com o n�mero de a��es.
   * 
   * @param symbol o s�mbolo
   * @param value o valor a ser abatido
   */
  public synchronized void decrementStockValue(String symbol, float value) {
    float newValue = getStockValue(symbol) - value;
    myStock.put(symbol, newValue);
  }
}
