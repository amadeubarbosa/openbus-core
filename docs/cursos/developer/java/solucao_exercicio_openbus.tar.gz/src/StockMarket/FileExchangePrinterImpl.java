package StockMarket;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import scs.core.servant.ComponentContext;

/**
 * FileExchangePrinterImpl implementa a faceta ExchangePrinter
 */
public class FileExchangePrinterImpl extends ExchangePrinterPOA {
  /**
   * O contexto do componente ao qual esta faceta pertence.
   */
  private ComponentContext context;
  /**
   * O stream para o arquivo de sa�da.
   */
  private FileWriter writer;
  /**
   * 
   */
  private final File DEFAULT_FILE = new File("./saida.out");

  /**
   * Construtor
   * 
   * @param context o contexto do componente dono da faceta.
   */
  public FileExchangePrinterImpl(ComponentContext context) {
    this.context = context;
    setFile(DEFAULT_FILE);
  }

  /**
   * Atribui um arquivo para escrita.
   * 
   * @param f o arquivo
   */
  public void setFile(File f) {
    try {
      this.writer = new FileWriter(f);
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void print(String text) {
    try {
      writer.write(text);
      writer.flush();
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Obt�m a faceta IComponent do componente.
   * 
   * @return a faceta IComponent
   */
  public org.omg.CORBA.Object _get_component() {
    return context.getIComponent();
  }
}
