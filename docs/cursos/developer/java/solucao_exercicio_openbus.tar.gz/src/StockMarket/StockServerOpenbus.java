package StockMarket;

import java.io.IOException;
import java.io.InputStream;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.util.Properties;
import java.util.logging.Level;

import org.omg.CORBA.UserException;

import scs.core.ComponentId;
import scs.core.IComponent;
import scs.core.IComponentHelper;
import scs.core.ReceptacleDescription;
import scs.core.servant.ComponentBuilder;
import scs.core.servant.ComponentContext;
import scs.core.servant.ExtendedFacetDescription;
import tecgraf.openbus.Openbus;
import tecgraf.openbus.core.v1_05.registry_service.IRegistryService;
import tecgraf.openbus.core.v1_05.registry_service.Property;
import tecgraf.openbus.core.v1_05.registry_service.ServiceOffer;
import tecgraf.openbus.exception.OpenbusAlreadyInitializedException;
import tecgraf.openbus.exception.RSUnavailableException;
import tecgraf.openbus.util.CryptoUtils;
import tecgraf.openbus.util.Log;

/**
 * Exemplo de um servidor que oferta um componente de servi�o para o OpenBus. O
 * componente oferece um componente que implementa a faceta
 * <code>StockServer</code>.
 * 
 * @author Tecgraf PUC-Rio
 */
public class StockServerOpenbus {

  /**
   * Nome do arquivo que possui as propriedades para execu��o do servidor.
   */
  public static final String SERVER_PROP_FILE = "/server.properties";

  /**
   * Executa as etapas de constru��o do um servidor que utiliza o openbus para
   * registrar uma oferta de um servi�o StockServer.
   * 
   * @param args os par�metros passados pela linha de comando
   * @throws StockServerOpenbusException se ocorrer algum erro durante a
   *         execu��o do exemplo
   */
  private void run(String[] args) throws StockServerOpenbusException {
    Properties props = loadProperties();
    initOpenbus(args, props);
    IRegistryService registryService = connectWithOpenBus(props);
    //IRegistryService registryService = connectWithOpenBusByLogin(props);
    ComponentContext context = createComponent(props);
    String registrationId = registerServiceOffer(registryService, context);
    Runtime.getRuntime().addShutdownHook(new ShutdownThread(registrationId));
    Openbus.getInstance().getORB().run();
  }

  /**
   * Carrega as propriedades do exemplo StockServer.
   * 
   * @return as propriedades carregadas a partir do arquivo
   *         {@link #SERVER_PROP_FILE}
   * @throws StockServerOpenbusException se houver um erro durante a carga das
   *         propriedades
   */
  private Properties loadProperties() throws StockServerOpenbusException {
    Properties props = new Properties();
    InputStream in =
      StockServerOpenbus.class.getResourceAsStream(SERVER_PROP_FILE);
    if (in != null) {
      try {
        props.load(in);
      }
      catch (IOException e) {
        throw new StockServerOpenbusException(
          "Erro ao carregar o arquivo de propriedades " + SERVER_PROP_FILE, e);
      }
      finally {
        try {
          in.close();
        }
        catch (IOException e) {
          throw new StockServerOpenbusException(
            "Erro ao fechar o arquivo de propriedades " + SERVER_PROP_FILE, e);
        }
      }
      return props;
    }
    else {
      throw new StockServerOpenbusException(
        "Erro ao abrir o arquivo de propriedades " + SERVER_PROP_FILE);
    }
  }

  /**
   * Faz a inicializa��o do Openbus. Configura as propriedades do ORB com os
   * argumentos passados na linha de comando e com as propriedades para o uso do
   * Jacorb.
   * 
   * @param args argumentos passados pela linha de comando
   * @param props propriedades do arquivo
   * @throws StockServerOpenbusException se ocorrer um erro durante a
   *         inicializa��o do Openbus.
   */
  private void initOpenbus(String[] args, Properties props)
    throws StockServerOpenbusException {
    String host = props.getProperty("host.name");
    String portString = props.getProperty("host.port");
    int port = Integer.valueOf(portString);
    String ip = props.getProperty("OAIAddr");

    Log.setLogsLevel(Level.WARNING);
    Properties orbProps = new Properties();
    orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
    orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
      "org.jacorb.orb.ORBSingleton");
    if (ip != null) {
      orbProps.setProperty("OAIAddr", ip);
    }
    Openbus bus = Openbus.getInstance();

    try {
      bus.init(args, orbProps, host, port);
    }
    catch (OpenbusAlreadyInitializedException e) {
      throw new StockServerOpenbusException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
    catch (UserException e) {
      throw new StockServerOpenbusException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
  }

  private IRegistryService connectWithOpenBusByLogin(Properties props)
    throws StockServerOpenbusException {
    String user = props.getProperty("user");
    String password = props.getProperty("password");
    System.out.println("user=" + user);
    System.out.println("password=" + password);
    Openbus bus = Openbus.getInstance();
    try {
      IRegistryService registryService = bus.connect(user, password);
      if (registryService == null) {
        throw new RSUnavailableException();
      }
      System.out.println("Stock Server conectado.");
      return registryService;
    }
    catch (Exception e) {
      throw new StockServerOpenbusException(
        "Erro ao fazer a conex�o com o Openbus", e);
    }
  }

  /**
   * Obt�m o servi�o de registro resultado da conex�o com o Openbus.
   * 
   * @param props as propriedades que possuem as informa��es com o nome da
   *        entidade do certificado, o nome do arquivo com a chave privada
   *        correspondente e o nome do arquivo com o certificado p�blico do
   *        servi�o de acesso.
   * @return a refer�ncia para o servi�o de registro
   * 
   * @throws StockServerOpenbusException se houver algum erro durante a conex�o
   *         com o servi�o de acesso do openbus.
   */
  private IRegistryService connectWithOpenBus(Properties props)
    throws StockServerOpenbusException {
    String entityName = props.getProperty("entity.name");
    String privateKeyFile = props.getProperty("private.key");
    String acsCertificateFile = props.getProperty("acs.certificate");

    /* Arquivo com a chave privada. */
    RSAPrivateKey privateKey;
    try {
      privateKey = CryptoUtils.readPrivateKey(privateKeyFile);
    }
    catch (Exception e) {
      throw new StockServerOpenbusException(
        "Erro ao ler o arquivo com a chave privada", e);
    }
    /* Arquivo com o certificado p�blico do Servi�o de Acesso */
    X509Certificate acsCertificate;
    try {
      acsCertificate = CryptoUtils.readCertificate(acsCertificateFile);
    }
    catch (Exception e) {
      throw new StockServerOpenbusException(
        "Erro ao ler o arquivo com o certificado p�blico do ACS", e);
    }
    Openbus bus = Openbus.getInstance();
    try {
      IRegistryService registryService =
        bus.connect(entityName, privateKey, acsCertificate);
      if (registryService == null) {
        throw new RSUnavailableException();
      }
      return registryService;
    }
    catch (Exception e) {
      throw new StockServerOpenbusException(
        "Erro ao fazer a conex�o com o Openbus", e);
    }
  }

  /**
   * Cria o componente SCS que implementa a faceta StockServer.
   * 
   * @param props as propriedades que possuem a informa��o do nome da classe que
   *        implementa a faceta do componente
   * @return o contexto do componente criado
   * @throws StockServerOpenbusException se ocorrer algum erro durante a cria��o
   *         do componente SCS
   * 
   */
  private ComponentContext createComponent(Properties props)
    throws StockServerOpenbusException {

    Openbus bus = Openbus.getInstance();
    ComponentBuilder builder =
      new ComponentBuilder(bus.getRootPOA(), bus.getORB());

    ComponentId componentId =
      new ComponentId("StockSeller", (byte) 1, (byte) 0, (byte) 0, "Java");

    ComponentContext context = new StockSellerContextImpl(builder, componentId);

    ExtendedFacetDescription[] facetDescriptions =
      createFacetDescriptions(props);
    ReceptacleDescription[] recDescriptions = createReceptacleDescriptions();

    try {
      context =
        builder.newComponent(facetDescriptions, recDescriptions, componentId,
          context);
      return context;
    }
    catch (Exception e) {
      throw new StockServerOpenbusException("Erro ao criar o componente SCS", e);
    }
  }

  /**
   * Cria os descritores das facetas implementadas pelo componente.
   * 
   * @param props as propriedades com os nomes das classes que implementam as
   *        facetas
   * @return um array com os descritores das facetas
   */
  private ExtendedFacetDescription[] createFacetDescriptions(Properties props) {
    String stockServerFacetClass = props.getProperty("stockserver.class");
    String stockExchageFacetClass = props.getProperty("stockexchange.class");
    ExtendedFacetDescription[] facetDescriptions =
      new ExtendedFacetDescription[2];
    facetDescriptions[0] =
      new ExtendedFacetDescription("StockServer", StockServerHelper.id(),
        stockServerFacetClass);
    facetDescriptions[1] =
      new ExtendedFacetDescription("StockExchange", StockExchangeHelper.id(),
        stockExchageFacetClass);
    return facetDescriptions;
  }

  /**
   * Cria os descritores dos recept�culos usados pelo componente.
   * 
   * @return um array com os descritores dos recept�culos
   */
  private ReceptacleDescription[] createReceptacleDescriptions() {
    ReceptacleDescription[] recDescriptions = new ReceptacleDescription[1];
    recDescriptions[0] =
      new ReceptacleDescription("ExchangePrinter", ExchangePrinterHelper.id(),
        true, null);
    return recDescriptions;
  }

  /**
   * Registra uma oferta de servi�o de um componente SCS que implementa a faceta
   * StockServer.
   * 
   * @param registryService o servi�o de registro do Openbus
   * @param context o contexto do componente para o qual a oferta de servi�o
   *        ser� criada
   * @return o identificador da oferta de servi�o
   * @throws StockServerOpenbusException se ocorrer erro durante o registro de a
   *         oferta de servi�o.
   */
  private String registerServiceOffer(IRegistryService registryService,
    ComponentContext context) throws StockServerOpenbusException {
    org.omg.CORBA.Object obj = context.getIComponent();
    IComponent component = IComponentHelper.narrow(obj);
    Property registrationProps[] = new Property[0];
    /*
     * Property registrationProps[] = new Property[1]; registrationProps[0] =
     * new Property(); registrationProps[0].name = "facets";
     * registrationProps[0].value = new String[2]; registrationProps[0].value[0]
     * = StockServerHelper.id(); registrationProps[0].value[1] =
     * StockExchangeHelper.id();
     */
    ServiceOffer serviceOffer = new ServiceOffer(registrationProps, component);
    try {
      String registrationId = registryService.register(serviceOffer);
      System.out.println("Stock Server registrado.");
      return registrationId;
    }
    catch (Exception e) {
      throw new StockServerOpenbusException(
        "Erro ao registrar a oferta do componente SCS", e);
    }
  }

  /**
   * Programa principal que inicia a execu��o do servidor.
   * 
   * @param args os argumentos passados pela linha de comando
   */
  public static void main(String[] args) {
    StockServerOpenbus demo = new StockServerOpenbus();
    try {
      demo.run(args);
    }
    catch (Throwable e) {
      e.printStackTrace();
    }
  }

  /**
   * A thread de ShutdowHook.
   * 
   */
  private static class ShutdownThread extends Thread {
    /**
     * O identificador da oferta de servi�o que deve ser removido do barramento
     * quando o servidor finalizar.
     */
    private String registrationId;

    /**
     * Construtor da thread de ShutdowHook
     * 
     * @param registrationId identificador da oferta de servi�o que deve ser
     *        removida do barramento quando o servidor finalizar.
     */
    ShutdownThread(String registrationId) {
      this.registrationId = registrationId;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void run() {
      Openbus bus = Openbus.getInstance();
      IRegistryService registryService = bus.getRegistryService();
      registryService.unregister(registrationId);
      bus.disconnect();
    }
  }

  /**
   * Exce��o usada no exemplo para reportar os erros durante a execu��o.
   */
  class StockServerOpenbusException extends Exception {
    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     */
    public StockServerOpenbusException(String msg) {
      super(msg);
    }

    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     * @param t a causa do erro
     */
    public StockServerOpenbusException(String msg, Throwable t) {
      super(msg, t);
    }
  }
}
