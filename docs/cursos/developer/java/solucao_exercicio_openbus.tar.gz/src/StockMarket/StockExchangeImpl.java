package StockMarket;

import java.util.List;

import scs.core.ConnectionDescription;
import scs.core.servant.ComponentContext;
import scs.core.servant.Receptacle;
import tecgraf.openbus.Openbus;
import tecgraf.openbus.core.v1_05.access_control_service.Credential;

/**
 * StockExchangeImpl implementa a faceta StockExchange
 */
public class StockExchangeImpl extends StockExchangePOA {

  /**
   * O contexto do componente ao qual esta faceta pertence.
   */
  private StockSellerContextImpl context;

  /**
   * Construtor
   * 
   * @param context o contexto do componente dono da faceta.
   */
  public StockExchangeImpl(ComponentContext context) {
    this.context = StockSellerContextImpl.class.cast(context);
    System.out.println("Criando o Servant StockExchangeImpl");
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean buyStock(String symbol) {
    System.out.println("Recebendo uma requisi��o buyStock");
    if (!context.containsStockSymbol(symbol)
      || context.getStockValue(symbol) == 0.0F) {
      return false;
    }
    context.decrementStockValue(symbol, 1.0F);
    // Notifica os recept�culos ExchangePrinter
    Receptacle receptacle = context.getReceptacles().get("ExchangePrinter");
    if (receptacle == null) {
      return true;
    }
    List<ConnectionDescription> connections = receptacle.getConnections();
    for (ConnectionDescription connection : connections) {
      ExchangePrinter printer = ExchangePrinterHelper.narrow(connection.objref);
      Credential credential = Openbus.getInstance().getInterceptedCredential();
      String user;
      if (credential.delegate != null && !credential.delegate.isEmpty()) {
        user = credential.delegate;
      }
      else {
        user = credential.owner;
      }
      printer.print("Acao " + symbol + " foi comprada pelo usuario " + user
        + ".\n");
    }

    return true;
  }

  /**
   * Obt�m a faceta IComponent do componente.
   * 
   * @return a faceta IComponent
   */
  public org.omg.CORBA.Object _get_component() {
    return context.getIComponent();
  }

}
