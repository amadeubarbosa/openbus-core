package StockMarket;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;

import org.omg.CORBA.UserException;

import scs.core.IComponent;
import tecgraf.openbus.Openbus;
import tecgraf.openbus.core.v1_05.registry_service.IRegistryService;
import tecgraf.openbus.core.v1_05.registry_service.Property;
import tecgraf.openbus.core.v1_05.registry_service.ServiceOffer;
import tecgraf.openbus.exception.OpenbusAlreadyInitializedException;
import tecgraf.openbus.exception.RSUnavailableException;
import tecgraf.openbus.util.Log;

/**
 * Exemplo de um cliente que procura pela oferta um componente de servi�o que
 * implementa a faceta <code>StockServer</code> e <code>StockExchange</code>.
 * 
 * @author Tecgraf PUC-Rio
 */
public class StockClientOpenbus {
  /**
   * Nome do arquivo que possui as propriedades para execu��o do cliente.
   */
  public static final String CLIENT_PROP_FILE = "/client.properties";

  /**
   * Executa as etapas de constru��o do um cliente que utiliza o openbus para
   * procurar por uma oferta de um servi�o que oferece a faceta StockServer.
   * 
   * @param args os par�metros passados pela linha de comando
   * @throws StockClientOpenbusException se ocorrer algum erro durante a
   *         execu��o do exemplo
   */
  private void run(String[] args) throws StockClientOpenbusException {
    Properties props = loadProperties();
    Openbus bus = initOpenbus(args, props);
    IRegistryService registryService = connectWithOpenBus(props);
    StockServer stockServer =
      getStockServer(registryService, props.getProperty("registered_by"));
    System.out.println("--A��es de mercado obtidas do StockServer:");
    // Obt�m os s�mbolos de todas as a��es
    String[] stockSymbols = stockServer.getStockSymbols();
    // Mostra as a��es de mercado com seus respectivos valores
    for (int i = 0; i < stockSymbols.length; i++) {
      System.out.println(stockSymbols[i] + " "
        + stockServer.getStockValue(stockSymbols[i]));
    }
    StockExchange stockExchange = getStockExchange(registryService);
    // Compra uma a��o
    if (stockSymbols.length > 0) {
      String first = stockSymbols[0];
      System.out.println("--Compra a a��o :" + first);
      boolean success = stockExchange.buyStock(first);
      if (success) {
        System.out.println("--A��o " + first + " depois da negocia��o: "
          + stockServer.getStockValue(first));
      }
      else {
        System.out.println("--N�o foi possivel negociar a a��o " + first);
      }
    }

    bus.disconnect();
  }

  /**
   * Carrega as propriedades do exemplo StockServer.
   * 
   * @return as propriedades carregadas a partir do arquivo
   *         {@link #CLIENT_PROP_FILE}
   * @throws StockClientOpenbusException se houver um erro durante a carga das
   *         propriedades
   */
  private Properties loadProperties() throws StockClientOpenbusException {
    Properties props = new Properties();
    InputStream in =
      StockServerOpenbus.class.getResourceAsStream(CLIENT_PROP_FILE);
    if (in != null) {
      try {
        props.load(in);
      }
      catch (IOException e) {
        throw new StockClientOpenbusException(
          "Erro ao carregar o arquivo de propriedades " + CLIENT_PROP_FILE, e);
      }
      finally {
        try {
          in.close();
        }
        catch (IOException e) {
          throw new StockClientOpenbusException(
            "Erro ao fechar o arquivo de propriedades " + CLIENT_PROP_FILE, e);
        }
      }
      return props;
    }
    else {
      throw new StockClientOpenbusException(
        "Erro ao abrir o arquivo de propriedades " + CLIENT_PROP_FILE);
    }
  }

  /**
   * Faz a inicializa��o do Openbus. Configura as propriedades do ORB com os
   * argumentos passados na linha de comando e com as propriedades para o uso do
   * Jacorb.
   * 
   * @param args argumentos passados pela linha de comando
   * @param props propriedades do arquivo
   * @return o openbus iniciado
   * @throws StockClientOpenbusException se ocorrer um erro durante a
   *         inicializa��o do Openbus.
   */
  private Openbus initOpenbus(String[] args, Properties props)
    throws StockClientOpenbusException {
    String host = props.getProperty("host.name");
    String portString = props.getProperty("host.port");
    int port = Integer.valueOf(portString);
    String ip = props.getProperty("OAIAddr");

    Log.setLogsLevel(Level.WARNING);
    Properties orbProps = new Properties();
    orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
    orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
      "org.jacorb.orb.ORBSingleton");
    if (ip != null) {
      orbProps.setProperty("OAIAddr", ip);
    }
    Openbus bus = Openbus.getInstance();

    try {
      bus.init(args, orbProps, host, port);
      return bus;
    }
    catch (OpenbusAlreadyInitializedException e) {
      throw new StockClientOpenbusException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
    catch (UserException e) {
      throw new StockClientOpenbusException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
  }

  /**
   * Obt�m o servi�o de registro resultado da conex�o com o Openbus.
   * 
   * @param props as propriedades que possuem as informa��es com o nome da
   *        entidade do certificado, o nome do arquivo com a chave privada
   *        correspondente e o nome do arquivo com o certificado p�blico do
   *        servi�o de acesso.
   * @return a refer�ncia para o servi�o de registro
   * 
   * @throws StockClientOpenbusException se houver algum erro durante a conex�o
   *         com o servi�o de acesso do openbus.
   */
  private IRegistryService connectWithOpenBus(Properties props)
    throws StockClientOpenbusException {
    String userLogin = props.getProperty("login");
    String userPassword = props.getProperty("password");
    Openbus bus = Openbus.getInstance();
    try {
      IRegistryService registryService = bus.connect(userLogin, userPassword);
      if (registryService == null) {
        throw new RSUnavailableException();
      }
      System.out.println("Stock Client conectado.");
      return registryService;
    }
    catch (Exception e) {
      throw new StockClientOpenbusException(
        "Erro ao fazer a conex�o com o Openbus", e);
    }
  }

  /**
   * Procura por um componente de servi�o e retorna a faceta StockServer que
   * esse componente oferece.
   * 
   * @param registryService o servi�o de registro que possui a componente
   *        registrado
   * @param registered_by nome da entidade que publicou o servi�o
   * @return a faceta StockServer do componente encontrado
   */
  private StockServer getStockServer(IRegistryService registryService,
    String registered_by) {
    /*
     * ServiceOffer[] servicesOffers = registryService.find(new String[] {
     * "StockServer"});
     */
    Property prop =
      new Property("registered_by", new String[] { registered_by });
    ServiceOffer[] servicesOffers =
      registryService.findByCriteria(new String[] { "StockServer",
          "StockExchange" }, new Property[] { prop });
    ServiceOffer serviceOffer = servicesOffers[0];
    IComponent component = serviceOffer.member;
    org.omg.CORBA.Object stockServerObject =
      component.getFacetByName("StockServer");
    return StockServerHelper.narrow(stockServerObject);
  }

  /**
   * Procura por um componente de servi�o e retorna a faceta StockExchange que
   * esse componente oferece.
   * 
   * @param registryService o servi�o de registro que possui a componente
   *        registrado
   * @return a faceta StockServer do componente encontrado
   */
  private StockExchange getStockExchange(IRegistryService registryService) {
    ServiceOffer[] servicesOffers =
      registryService.find(new String[] { "StockServer" });
    ServiceOffer serviceOffer = servicesOffers[0];
    IComponent component = serviceOffer.member;
    org.omg.CORBA.Object stockExchangeObject =
      component.getFacetByName("StockExchange");
    return StockExchangeHelper.narrow(stockExchangeObject);
  }

  /**
   * Programa principal que executa o cliente.
   * 
   * @param args os argumentos passados pela linha de comando
   */
  public static void main(String[] args) {
    StockClientOpenbus demo = new StockClientOpenbus();
    try {
      demo.run(args);
    }
    catch (Throwable e) {
      e.printStackTrace();
    }
  }

  /**
   * Exce��o usada no exemplo para reportar os erros durante a execu��o.
   */
  class StockClientOpenbusException extends Exception {
    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     */
    public StockClientOpenbusException(String msg) {
      super(msg);
    }

    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     * @param t a causa do erro
     */
    public StockClientOpenbusException(String msg, Throwable t) {
      super(msg, t);
    }
  }
}
