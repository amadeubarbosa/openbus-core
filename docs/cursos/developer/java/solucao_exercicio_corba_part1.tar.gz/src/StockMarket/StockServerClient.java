package StockMarket;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import org.omg.CORBA.ORB;

/**
 * Exemplo de um cliente que faz chamadas ao objeto CORBA definido pela IDL
 * StockMarket::StockServer
 */
public class StockServerClient {

  /**
   * Refer�ncia para o objeto CORBA StockMarket::StockServer
   */
  private StockServer myStock;

  /**
   * Construtor
   * 
   * @param myStock a refer�ncia para o objeto CORBA StockServer
   */
  public StockServerClient(StockServer myStock) {
    this.myStock = myStock;
  }

  /**
   * Executa o cliente
   */
  public void run() {
    try {
      System.out.println("A��es de mercado obtidas do StockServer:");
      // Obt�m os s�mbolos de todos as a��es
      String[] stockSymbols = myStock.getStockSymbols();
      // Mostra as a��es de mercado com seus respectivos valores
      for (int i = 0; i < stockSymbols.length; i++) {
        System.out.println(stockSymbols[i] + " "
          + myStock.getStockValue(stockSymbols[i]));
      }
    }
    catch (org.omg.CORBA.SystemException e) {
      e.printStackTrace();
    }
  }

  /**
   * Programa principal que recebe como argumento o nome do arquivo do qual l� o
   * IOR do objeto CORBA StockServer
   * 
   * @param args um array com um �nico argumento que deve ser o nome de um
   *        arquivo
   */
  public static void main(String args[]) {
    try {
      // As propriedades que informam o uso do JacORB como ORB.
      Properties orbProps = new Properties();
      orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
      orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
        "org.jacorb.orb.ORBSingleton");

      // Inicializa o ORB.
      ORB orb = ORB.init(args, orbProps);

      // L� o IOR do arquivo cujo nome � passado como par�metro
      BufferedReader reader =
        new BufferedReader(new InputStreamReader(new FileInputStream(args[0])));
      String ior = reader.readLine();

      // Obt�m a refer�ncia para objeto CORBA
      org.omg.CORBA.Object obj = orb.string_to_object(ior);
      StockServer myStock = StockServerHelper.narrow(obj);

      // Executa as chamadas ao objeto CORBA
      StockServerClient stockClient = new StockServerClient(myStock);
      stockClient.run();
    }
    catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    catch (IOException e) {
      e.printStackTrace();
    }
    catch (Throwable e) {
      e.printStackTrace();
    }

  }
}
