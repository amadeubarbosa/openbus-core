import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Properties;
import java.util.logging.Level;

import org.omg.CORBA.UserException;
import org.omg.CORBA_2_3.ORB;

import scs.core.IComponent;
import tecgraf.ftc.common.logic.RemoteFileChannel;
import tecgraf.ftc.common.logic.RemoteFileChannelImpl;
import tecgraf.ftc.utils.Utils;
import tecgraf.openbus.Openbus;
import tecgraf.openbus.core.v1_05.registry_service.IRegistryService;
import tecgraf.openbus.core.v1_05.registry_service.Property;
import tecgraf.openbus.core.v1_05.registry_service.ServiceOffer;
import tecgraf.openbus.data_service.DataAccessDenied;
import tecgraf.openbus.data_service.DataDescription;
import tecgraf.openbus.data_service.DataDescriptionFactory;
import tecgraf.openbus.data_service.DataDescriptionHelper;
import tecgraf.openbus.data_service.DataKey;
import tecgraf.openbus.data_service.IHierarchicalDataService;
import tecgraf.openbus.data_service.IHierarchicalDataServiceHelper;
import tecgraf.openbus.data_service.Metadata;
import tecgraf.openbus.data_service.ServiceFailure;
import tecgraf.openbus.data_service.UnstructuredData;
import tecgraf.openbus.data_service.UnstructuredDataFactory;
import tecgraf.openbus.data_service.UnstructuredDataHelper;
import tecgraf.openbus.data_service.project.ProjectItemDescriptionFactory;
import tecgraf.openbus.data_service.project.ProjectItemDescriptionImpl;
import tecgraf.openbus.exception.OpenbusAlreadyInitializedException;
import tecgraf.openbus.exception.RSUnavailableException;
import tecgraf.openbus.project.ProjectItemDescription;
import tecgraf.openbus.project.ProjectItemDescriptionHelper;
import tecgraf.openbus.util.Log;

/**
 * Exemplo de um cliente que se conecta ao barramento e usa o servi�o de dados
 * IHierarchicalDataService publicado pelo servi�o de projetos de um sistema
 * CSBase.
 * 
 * O exemplo lista o conte�do das pastas de um determinado projeto.
 * 
 * @author Tecgraf PUC-Rio
 */
public class ProjectServiceClient {
  /**
   * Nome do arquivo que possui as propriedades para execu��o do cliente.
   */
  public static final String CLIENT_PROP_FILE = "/client.properties";

  /**
   * Refer�ncia para o componente que implementa a faceta
   * IHierarchicalDataService
   */
  private IHierarchicalDataService dataService;

  /**
   * Login do usu�rio
   */
  private String userLogin;

  /**
   * Executa as etapas de constru��o do um cliente que utiliza o openbus para
   * procurar por uma oferta de um servi�o que oferece a faceta
   * IHierchicalDataService.
   * 
   * @param args os par�metros passados pela linha de comando
   * @throws ProjectServiceClientException se ocorrer algum erro durante a
   *         execu��o do exemplo
   */
  private void run(String[] args) throws ProjectServiceClientException {
    Properties props = loadProperties();
    Openbus bus = initOpenbus(args, props);
    /*
     * Registra no ORB as f�bricas dos objetos que s�o passados como par�metros
     * nas chamadas ao servi�o para que o mecanismo de marshall e unmarshall
     * saiba como criar esses objetos.
     */
    ORB orb = (ORB) bus.getORB();
    orb.register_value_factory(DataDescriptionHelper.id(),
      new DataDescriptionFactory());
    orb.register_value_factory(ProjectItemDescriptionHelper.id(),
      new ProjectItemDescriptionFactory());
    orb.register_value_factory(UnstructuredDataHelper.id(),
      new UnstructuredDataFactory());
    /* Faz a conex�o com o barramento e recupara o servi�o de dados */
    IRegistryService registryService = connectWithOpenBus(props);
    dataService = getIDataService(props, registryService);
    /* Obt�m o descritor da pasta do projeto */
    String projectName = props.getProperty("dataservice.project.name");
    DataDescription projectDesc = openProject(projectName);
    if (projectDesc == null) {
      throw new ProjectServiceClientException(
        "O usu�rio n�o possui um projeto com o nome " + projectName);
    }
    /*
     * Exibe o conte�do da pasta principal do projeto.
     */
    showFolder(3, projectDesc);
    String fileName = props.getProperty("dataservice.file.name");
    File file = new File(fileName);
    byte[] bytes = readLocalFile(file);
    DataDescription desc = createRemoteFile(file.getName(), bytes, projectDesc);
    bytes = readRemoteFile(desc);
    System.out.println("O conte�do do arquivo remoto " + fileName + "�:");
    System.out.println(new String(bytes));
    bus.disconnect();
  }

  /**
   * Obt�m o descritor utilizado pelo DataService para a pasta do projeto cujo
   * nome � informado. Retorna null se n�o for encontrado um projeto com o nome
   * informado.
   * 
   * @param projectName nome do projeto
   * @return o descritor da pasta do projeto ou null se o projeto n�o for
   *         encontrado
   * @throws ProjectServiceClientException se houver um erro ao abrir a pasta do
   *         projeto
   */
  public DataDescription openProject(String projectName)
    throws ProjectServiceClientException {
    DataDescription[] rootDescList;
    try {
      rootDescList = dataService.getRoots();
      if (rootDescList.length < 1) {
        throw new ProjectServiceClientException("O usu�rio n�o possui projetos");
      }
      for (int i = 0; i < rootDescList.length; i++) {
        DataDescription rootDesc = rootDescList[i];
        if (!(rootDesc instanceof ProjectItemDescription)) {
          throw new ProjectServiceClientException("Descritor inv�lido:"
            + rootDesc.toString());
        }
        if (rootDesc.fName.equals(projectName)) {
          return rootDesc;
        }
      }
    }
    catch (ServiceFailure e) {
      throw new ProjectServiceClientException(
        "Falha no acesso ao servi�o. Verifique se o usu�rio � um usu�rio v�lido",
        e);
    }
    catch (DataAccessDenied e) {
      throw new ProjectServiceClientException("Falha no acesso ao servi�o.", e);
    }
    return null;
  }

  /**
   * Exibe o conte�do de uma pasta do projeto.
   * 
   * @param count o n�mero de caracteres para identar a apresenta��o dos filhos
   * @param desc descritor usado pelo IHierarchicalDataService para representar
   *        um n� na hierarquia (pode ser uma pasta ou ou arquivo)
   * @throws ProjectServiceClientException se houver algum erro durante a
   *         exibi��o do conte�do da pasta
   */
  private void showFolder(int count, DataDescription desc)
    throws ProjectServiceClientException {
    try {
      StringBuffer ident = new StringBuffer();
      for (int i = 0; i < count; i++) {
        ident.append(' ');
      }
      DataDescription[] children = dataService.getChildren(desc.fKey);
      for (DataDescription child : children) {
        String childName = child.fName;
        ProjectItemDescription childDesc =
          (ProjectItemDescription) dataService.getDataDescription(child.fKey);
        if (childDesc.fIsContainer) {
          System.out.println(ident + "+ Diretorio: " + childName);
          showFolder(count + 3, child);
        }
        else {
          System.out.println(ident + "- Arquivo: " + childName);
        }
      }
    }
    catch (Exception e) {
      throw new ProjectServiceClientException(
        "Erro na exibi��o do conte�do da pasta" + desc.fName, e);
    }
  }

  /**
   * L� o conte�do de um arquivo local.
   * 
   * @param file o arquivo a ser lidao
   * @return os bytes do arquivo lido
   * @throws ProjectServiceClientException se houver algum erro durante a
   *         leitura
   */
  private byte[] readLocalFile(File file) throws ProjectServiceClientException {
    try {
      InputStream is = new FileInputStream(file);
      long length = file.length();
      byte[] bytes = new byte[(int) length];
      int offset = 0;
      int numRead = 0;
      while (offset < bytes.length
        && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
        offset += numRead;
      }
      if (offset < bytes.length) {
        throw new ProjectServiceClientException(
          "N�o foi poss�vel completar a leitura do arquivo " + file.getName());
      }
      is.close();
      return bytes;
    }
    catch (FileNotFoundException e) {
      throw new ProjectServiceClientException("Arquivo "
        + file.getAbsolutePath() + " n�o encontrado", e);
    }
    catch (IOException e) {
      throw new ProjectServiceClientException("Erro na leitura do arquivo "
        + file.getAbsolutePath(), e);
    }
  }

  /**
   * Cria um novo arquivo com o conte�do passado como par�metro, na pasta
   * informada. O programa assume que o arquivo n�o existe.
   * 
   * @param fileName nome do arquivo a ser criado
   * @param data o array com os bytes a serem escritos no arquivo
   * @param desc a pasta na qual o arquivo ser� criado
   * @return o descritor do novo arquivo criado
   * @throws ProjectServiceClientException se o arquivo j� existir ou se ocorrer
   *         algum erro durante a cria��o do arquivo.
   */
  public DataDescription createRemoteFile(String fileName, byte[] data,
    DataDescription desc) throws ProjectServiceClientException {
    try {
      long currentDate = Calendar.getInstance().getTimeInMillis();
      ProjectItemDescription prototype =
        new ProjectItemDescriptionImpl(fileName, new HashSet<String>(),
          new ArrayList<Metadata>(), userLogin, null, null, "TEXT", 0, false,
          true, true, currentDate, currentDate);
      byte[] fileKey = dataService.createData(desc.fKey, prototype);
      UnstructuredData view =
        (UnstructuredData) dataService.getDataView(fileKey,
          UnstructuredDataHelper.id());
      DataKey dataKey = new DataKey(view.fKey);
      RemoteFileChannel rfc =
        new RemoteFileChannelImpl(dataKey.getDataId().getBytes(
          Utils.CHARSET_ENCODING), view.fWritable, view.fHost, view.fPort,
          view.fAccessKey);
      rfc.open(false);
      rfc.write(data);
      rfc.close();
      return dataService.getDataDescription(fileKey);
    }
    catch (Exception e) {
      throw new ProjectServiceClientException(
        "Erro na cria��o de um arquivo na pasta", e);
    }
  }

  /**
   * L� um arquivo remoto
   * 
   * @param desc o descritor do arquivo a ser lisdo
   * @return os bytes lidos
   * @throws ProjectServiceClientException se o arquivo j� existir ou se ocorrer
   *         algum erro durante a cria��o do arquivo.
   */
  public byte[] readRemoteFile(DataDescription desc)
    throws ProjectServiceClientException {
    try {
      UnstructuredData view =
        (UnstructuredData) dataService.getDataView(desc.fKey,
          UnstructuredDataHelper.id());
      DataKey dataKey = new DataKey(view.fKey);
      RemoteFileChannel rfc =
        new RemoteFileChannelImpl(dataKey.getDataId().getBytes(
          Utils.CHARSET_ENCODING), view.fWritable, view.fHost, view.fPort,
          view.fAccessKey);
      rfc.open(true);
      int fileSize = (int) rfc.getSize();
      byte[] buffer = new byte[fileSize];
      if (fileSize != 0) {
        rfc.read(buffer);
      }
      rfc.close();
      return buffer;
    }
    catch (Exception e) {
      throw new ProjectServiceClientException(
        "Erro na leitura de um dado da pasta", e);
    }
  }

  /**
   * Utiliza o servi�o de registro do barramento para procurar pelo componente
   * DataService de acordo com as propriedades <b>dataservice.component.name</b>
   * e <b>dataservice.component.version</b>.
   * 
   * @param props as propriedades que possuem as informa��es com o nome e a
   *        vers�o do componente
   * @param registryService o servi�o de registro
   * @return o componente DataService que implementa a faceta
   *         <b>IHierarchicalDataService</b>.
   * @throws ProjectServiceClientException se houver algum erro na busca pelo
   *         servi�o DataService
   */
  private IHierarchicalDataService getIDataService(Properties props,
    IRegistryService registryService) throws ProjectServiceClientException {
    String entityNameProperty =
      props.getProperty("dataservice.entity_name").trim();
    Property property =
      new Property("registered_by", new String[] { entityNameProperty });
    /* Crit�rios usados para busca pelo componente de servi�o */
    String serviceName = "ProjectDataService";
    ServiceOffer[] servicesOffers =
      registryService.findByCriteria(new String[] { serviceName },
        new Property[] { property });
    if (servicesOffers.length == 0) {
      throw new ProjectServiceClientException("N�o foi encontrado um servi�o " +
        serviceName + " registrado por: " + entityNameProperty);
    }
    if (servicesOffers.length > 1) {
      throw new ProjectServiceClientException(
        "Foi encontrado mais de um servi�o " + serviceName + 
        " registrado por: " + entityNameProperty);
    }
    ServiceOffer serviceOffer = servicesOffers[0];
    IComponent component = serviceOffer.member;
    /*
     * Note que o componente de servi�o implementa a faceta
     * IHierarchicalDataService e � essa faceta que a demo utiliza.
     */
    IHierarchicalDataService dataService =
      IHierarchicalDataServiceHelper.narrow(component
        .getFacet(IHierarchicalDataServiceHelper.id()));

    return dataService;
  }

  /**
   * Carrega as propriedades do exemplo.
   * 
   * @return as propriedades carregadas a partir do arquivo
   *         {@link #CLIENT_PROP_FILE}
   * @throws ProjectServiceClientException se houver um erro durante a carga das
   *         propriedades
   */
  private Properties loadProperties() throws ProjectServiceClientException {
    Properties props = new Properties();
    InputStream in =
      ProjectServiceClient.class.getResourceAsStream(CLIENT_PROP_FILE);
    if (in != null) {
      try {
        props.load(in);
      }
      catch (IOException e) {
        throw new ProjectServiceClientException(
          "Erro ao carregar o arquivo de propriedades " + CLIENT_PROP_FILE, e);
      }
      finally {
        try {
          in.close();
        }
        catch (IOException e) {
          throw new ProjectServiceClientException(
            "Erro ao fechar o arquivo de propriedades " + CLIENT_PROP_FILE, e);
        }
      }
      return props;
    }
    else {
      throw new ProjectServiceClientException(
        "Erro ao abrir o arquivo de propriedades " + CLIENT_PROP_FILE);
    }
  }

  /**
   * Faz a inicializa��o do Openbus. Configura as propriedades do ORB com os
   * argumentos passados na linha de comando e com as propriedades para o uso do
   * Jacorb.
   * 
   * @param args argumentos passados pela linha de comando
   * @param props propriedades do arquivo
   * @return o openbus iniciado
   * @throws ProjectServiceClientException se ocorrer um erro durante a
   *         inicializa��o do Openbus.
   */
  private Openbus initOpenbus(String[] args, Properties props)
    throws ProjectServiceClientException {
    String host = props.getProperty("host.name");
    String portString = props.getProperty("host.port");
    int port = Integer.valueOf(portString);
    String ip = props.getProperty("OAIAddr");

    Log.setLogsLevel(Level.WARNING);
    Properties orbProps = new Properties();
    orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
    orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
      "org.jacorb.orb.ORBSingleton");
    if (ip != null) {
      orbProps.setProperty("OAIAddr", ip);
    }
    Openbus bus = Openbus.getInstance();
    try {
      bus.init(args, orbProps, host, port);
      return bus;

    }
    catch (OpenbusAlreadyInitializedException e) {
      throw new ProjectServiceClientException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
    catch (UserException e) {
      throw new ProjectServiceClientException(
        "Erro durante a inicializa��o do Openbus.", e);
    }
  }

  /**
   * Obt�m o servi�o de registro resultado da conex�o com o Openbus.
   * 
   * @param props as propriedades que possuem as informa��es com o nome da
   *        entidade do certificado, o nome do arquivo com a chave privada
   *        correspondente e o nome do arquivo com o certificado p�blico do
   *        servi�o de acesso.
   * @return a refer�ncia para o servi�o de registro
   * 
   * @throws ProjectServiceClientException se houver algum erro durante a
   *         conex�o com o servi�o de acesso do openbus.
   */
  private IRegistryService connectWithOpenBus(Properties props)
    throws ProjectServiceClientException {
    String userLogin = props.getProperty("login");
    String userPassword = props.getProperty("password");
    Openbus bus = Openbus.getInstance();
    try {
      IRegistryService registryService = bus.connect(userLogin, userPassword);
      if (registryService == null) {
        throw new RSUnavailableException();
      }
      return registryService;
    }
    catch (Exception e) {
      throw new ProjectServiceClientException(
        "Erro ao fazer a conex�o com o Openbus", e);
    }
  }

  /**
   * Programa principal que executa o cliente.
   * 
   * @param args os argumentos passados pela linha de comando
   */
  public static void main(String[] args) {
    ProjectServiceClient client = new ProjectServiceClient();
    try {
      client.run(args);
    }
    catch (Throwable e) {
      e.printStackTrace();
    }
  }

  /**
   * Exce��o usada no exemplo para reportar os erros durante a execu��o.
   */
  class ProjectServiceClientException extends Exception {
    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     */
    public ProjectServiceClientException(String msg) {
      super(msg);
    }

    /**
     * Construtor.
     * 
     * @param msg a mensagem do erro
     * @param t a causa do erro
     */
    public ProjectServiceClientException(String msg, Throwable t) {
      super(msg, t);
    }
  }
}
