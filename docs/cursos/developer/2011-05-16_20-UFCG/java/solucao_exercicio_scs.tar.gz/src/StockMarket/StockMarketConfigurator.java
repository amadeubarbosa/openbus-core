package StockMarket;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import org.omg.CORBA.ORB;

import scs.core.IComponent;
import scs.core.IComponentHelper;
import scs.core.IReceptacles;
import scs.core.IReceptaclesHelper;

/**
 * Exemplo de um cliente que conecta um componente que implementa a faceta
 * ExchangePrinter com o componente StockSeller.
 * 
 * @author Tecgraf PUC-Rio
 */
public class StockMarketConfigurator {

  /**
   * Programa principal que executa o cliente.
   * 
   * @param args os argumentos passados pela linha de comando
   */
  public static void main(String[] args) {
    try {
      /*
       * As propriedades que informam o uso do JacORB como ORB.
       */
      Properties orbProps = new Properties();
      orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
      orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
        "org.jacorb.orb.ORBSingleton");

      /* Inicializa o ORB. */
      ORB orb = ORB.init(args, orbProps);

      /*
       * L� o IOR do componente StockSeller do arquivo cujo nome � passado como
       * par�metro 1.
       */
      BufferedReader reader =
        new BufferedReader(new InputStreamReader(new FileInputStream(args[0])));
      String ior_seller = reader.readLine();

      /*
       * L� o IOR do componente StockLogger do arquivo cujo nome � passado como
       * par�metro 2.
       */
      reader =
        new BufferedReader(new InputStreamReader(new FileInputStream(args[1])));
      String ior_logger = reader.readLine();

      /* Obt�m a refer�ncia para component StockSeller. */
      org.omg.CORBA.Object obj = orb.string_to_object(ior_seller);
      IComponent stockSeller = IComponentHelper.narrow(obj);

      /* Obt�m a refer�ncia para component StockLogger. */
      obj = orb.string_to_object(ior_logger);
      IComponent stockLogger = IComponentHelper.narrow(obj);

      /* Obt�m a refer�ncia para IReceptacles do StockSeller */
      IReceptacles irStockSeller =
        IReceptaclesHelper
          .narrow(stockSeller.getFacet(IReceptaclesHelper.id()));

      /*
       * Faz a conex�o do componente StockLogger nos recept�culos de
       * StockSeller. Note que a faceta ExchangePrinter do componente � usada
       * para a conex�o.
       */
      irStockSeller.connect("ExchangePrinter", ExchangePrinterHelper
        .narrow(stockLogger.getFacet(ExchangePrinterHelper.id())));

    }
    catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    catch (IOException e) {
      e.printStackTrace();
    }
    catch (Throwable e) {
      e.printStackTrace();
    }
  }
}
