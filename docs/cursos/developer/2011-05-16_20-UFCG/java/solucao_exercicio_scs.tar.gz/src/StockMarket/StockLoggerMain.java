package StockMarket;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Properties;

import org.omg.CORBA.ORB;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import scs.core.ComponentId;
import scs.core.IComponent;
import scs.core.IComponentHelper;
import scs.core.servant.ComponentBuilder;
import scs.core.servant.ComponentContext;
import scs.core.servant.ExtendedFacetDescription;

/**
 * Exemplo de um servidor que cria um componente StockLogger que possui a faceta
 * StockMarket::ExchangePrinter.
 */
public class StockLoggerMain {

  /**
   * Programa principal. Recebe como argumento o nome do arquivo local onde ser�
   * gravado o IOR para o objeto CORBA que representa o componente criado.
   * 
   * @param args um array com um �nico argumento que deve ser o nome de um
   *        arquivo
   */
  public static void main(String args[]) {

    try {

      /*
       * As propriedades que informam o uso do JacORB como ORB.
       */
      Properties orbProps = new Properties();
      orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
      orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
        "org.jacorb.orb.ORBSingleton");

      /* Inicializa o ORB */
      ORB orb = ORB.init(args, orbProps);
      /* Obt�m a refer�ncia para o POA e inicializa o POA */
      POA poa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
      poa.the_POAManager().activate();

      /* Cria o componente (IComponent) StockLogger */
      IComponent component = createComponent(orb, poa);

      /* Escreve no arquivo a refer�ncia para o objeto CORBA */
      PrintWriter ps = new PrintWriter(new FileOutputStream(new File(args[0])));
      ps.println(orb.object_to_string(component));
      ps.close();

      /* Bloqueia a thread corrente at� o ORB finalizar */
      orb.run();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Cria o componente SCS que implementa a faceta ExchangePrinter.
   * 
   * @param orb o ORB
   * @param poa o POA
   * @return o do componente criado
   * @throws Exception se ocorrer algum erro durante a cria��o do componente SCS
   */
  private static IComponent createComponent(ORB orb, POA poa) throws Exception {
    ComponentBuilder builder = new ComponentBuilder(poa, orb);
    ComponentId componentId =
      new ComponentId("StockLogger", (byte) 1, (byte) 0, (byte) 0, "Java");
    ExtendedFacetDescription[] facetDescriptions = createFacetDescriptions();
    ComponentContext context =
      builder.newComponent(facetDescriptions, null, componentId);
    org.omg.CORBA.Object obj = context.getIComponent();
    IComponent component = IComponentHelper.narrow(obj);
    return component;
  }

  /**
   * Cria os descritores das facetas implementadas pelo componente.
   * 
   * @return um array com os descritores das facetas
   */
  private static ExtendedFacetDescription[] createFacetDescriptions() {
    String displayPrinterFacetClass = "StockMarket.DisplayExchangePrinterImpl";
    ExtendedFacetDescription[] facetDescriptions =
      new ExtendedFacetDescription[1];
    facetDescriptions[0] =
      new ExtendedFacetDescription("DisplayExchangePrinter",
        ExchangePrinterHelper.id(), displayPrinterFacetClass);
    return facetDescriptions;
  }
}
