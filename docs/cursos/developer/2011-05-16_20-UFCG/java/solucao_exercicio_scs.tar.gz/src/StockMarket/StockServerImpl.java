package StockMarket;

import scs.core.servant.ComponentContext;

/**
 * StockServerImpl implementa a interface IDL StockServer
 */
public class StockServerImpl extends StockServerPOA {

  /**
   * O contexto do componente ao qual esta faceta pertence.
   */
  private StockSellerContextImpl context;

  /**
   * Construtor
   * 
   * @param context o contexto do componente dono da faceta.
   */
  public StockServerImpl(ComponentContext context) {
    this.context = StockSellerContextImpl.class.cast(context);
    System.out.println("Criando o Servant StockServerImpl");
  }

  /**
   * Retorna o valor corrente a determinada a��o do mercado, dado o s�mbolo que
   * a representa.
   */
  @Override
  public float getStockValue(String symbol) {
    System.out.println("Recebendo uma requisi��o getStockValue");
    // Tenta encontrar o simbolo
    if (context.containsStockSymbol(symbol)) {
      // Simbolo encontrado; retorna seu valor
      return context.getStockValue(symbol);
    }
    else {
      // Simbolo n�o foi encontrado
      return 0f;
    }
  }

  /**
   * Retorna a sequ�ncia com todos os s�mbolos que definem as a��es de mercado
   * mantidos por esse StockServer.
   */
  @Override
  public String[] getStockSymbols() {
    System.out.println("Recebendo uma requisi��o getStockSymbols");
    return context.getAllSymbols();
  }

  /**
   * Obt�m a faceta IComponent do componente.
   * 
   * @return a faceta IComponent
   */
  public org.omg.CORBA.Object _get_component() {
    return context.getIComponent();
  }
}
