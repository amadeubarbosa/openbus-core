package StockMarket;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Properties;

import org.omg.CORBA.ORB;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import scs.core.ComponentId;
import scs.core.IComponent;
import scs.core.IComponentHelper;
import scs.core.ReceptacleDescription;
import scs.core.servant.ComponentBuilder;
import scs.core.servant.ComponentContext;
import scs.core.servant.ExtendedFacetDescription;

/**
 * Exemplo de um servidor que cria um componente StockSeller que possui as
 * facetas StockMarket::StockServer e StockMarket::StockExchange.
 */
public class StockServerMain {

  /**
   * Programa principal. Recebe como argumento o nome do arquivo local onde ser�
   * gravado o IOR para o objeto CORBA que representa o componente criado.
   * 
   * @param args um array com um �nico argumento que deve ser o nome de um
   *        arquivo
   */
  public static void main(String args[]) {

    try {

      /*
       * As propriedades que informam o uso do JacORB como ORB.
       */
      Properties orbProps = new Properties();
      orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
      orbProps.setProperty("org.omg.CORBA.ORBSingletonClass",
        "org.jacorb.orb.ORBSingleton");

      /* Inicializa o ORB */
      ORB orb = ORB.init(args, orbProps);
      /* Obt�m a refer�ncia para o POA e inicializa o POA */
      POA poa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
      poa.the_POAManager().activate();

      /* Cria o componente (IComponent) StockSeller */
      IComponent component = createComponent(orb, poa);

      /* Escreve no arquivo a refer�ncia para o objeto CORBA */
      PrintWriter ps = new PrintWriter(new FileOutputStream(new File(args[0])));
      ps.println(orb.object_to_string(component));
      ps.close();

      /* Bloqueia a thread corrente at� o ORB finalizar */
      orb.run();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Cria o componente SCS que implementa a faceta StockServer.
   * 
   * @param orb o ORB
   * @param poa o POA
   * @return o do componente criado
   * @throws Exception se ocorrer algum erro durante a cria��o do componente SCS
   * 
   */
  private static IComponent createComponent(ORB orb, POA poa) throws Exception {
    ComponentBuilder builder = new ComponentBuilder(poa, orb);
    ComponentId componentId =
      new ComponentId("StockSeller", (byte) 1, (byte) 0, (byte) 0, "Java");
    ComponentContext context = new StockSellerContextImpl(builder, componentId);
    ExtendedFacetDescription[] facetDescriptions = createFacetDescriptions();
    ReceptacleDescription[] recDescriptions = createReceptacleDescriptions();
    context =
      builder.newComponent(facetDescriptions, recDescriptions, componentId,
        context);
    org.omg.CORBA.Object obj = context.getIComponent();
    IComponent component = IComponentHelper.narrow(obj);
    return component;
  }

  /**
   * Cria os descritores das facetas implementadas pelo componente.
   * 
   * @return um array com os descritores das facetas
   */
  private static ExtendedFacetDescription[] createFacetDescriptions() {
    String stockServerFacetClass = "StockMarket.StockServerImpl";
    String stockExchageFacetClass = "StockMarket.StockExchangeImpl";
    ExtendedFacetDescription[] facetDescriptions =
      new ExtendedFacetDescription[2];
    facetDescriptions[0] =
      new ExtendedFacetDescription("StockServer", StockServerHelper.id(),
        stockServerFacetClass);
    facetDescriptions[1] =
      new ExtendedFacetDescription("StockExchange", StockExchangeHelper.id(),
        stockExchageFacetClass);
    return facetDescriptions;
  }

  /**
   * Cria os descritores dos recept�culos usados pelo componente.
   * 
   * @return um array com os descritores dos recept�culos
   */
  private static ReceptacleDescription[] createReceptacleDescriptions() {
    ReceptacleDescription[] recDescriptions = new ReceptacleDescription[1];
    recDescriptions[0] =
      new ReceptacleDescription("ExchangePrinter", ExchangePrinterHelper.id(),
        true, null);
    return recDescriptions;
  }
}
