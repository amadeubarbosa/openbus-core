package StockMarket;

import java.util.List;

import scs.core.ConnectionDescription;
import scs.core.servant.ComponentContext;
import scs.core.servant.Receptacle;

/**
 * StockExchangeImpl implementa a interface IDL StockExchange
 */
public class StockExchangeImpl extends StockExchangePOA {

  /**
   * O contexto do componente ao qual esta faceta pertence.
   */
  private StockSellerContextImpl context;

  /**
   * Construtor
   * 
   * @param context o contexto do componente dono da faceta.
   */
  public StockExchangeImpl(ComponentContext context) {
    this.context = StockSellerContextImpl.class.cast(context);
    System.out.println("Criando o Servant StockExchangeImpl");
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public boolean buyStock(String symbol) {
    System.out.println("Recebendo uma requisi��o buyStock");
    if (!context.containsStockSymbol(symbol)
      || context.getStockValue(symbol) == 0.0F) {
      return false;
    }
    context.updateStockValue(symbol, 1.1F); // Incrementa em 10%
    // Notifica os recept�culos ExchangePrinter
    Receptacle receptacle = context.getReceptacles().get("ExchangePrinter");
    if (receptacle == null) {
      return true;
    }
    List<ConnectionDescription> connections = receptacle.getConnections();
    for (ConnectionDescription connection : connections) {
      ExchangePrinter printer = ExchangePrinterHelper.narrow(connection.objref);
      printer.print("A��o " + symbol + " foi negociada");
    }

    return true;
  }

  /**
   * Obt�m a faceta IComponent do componente.
   * 
   * @return a faceta IComponent
   */
  @Override
  public org.omg.CORBA.Object _get_component() {
    return context.getIComponent();
  }

}
