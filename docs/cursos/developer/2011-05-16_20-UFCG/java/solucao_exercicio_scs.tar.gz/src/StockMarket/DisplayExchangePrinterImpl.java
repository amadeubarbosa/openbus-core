package StockMarket;

import scs.core.servant.ComponentContext;

/**
 * DisplayExchangePrinterImpl implementa a interface IDL ExchangePrinter. Essa
 * implementa��o usa o display (console) para mostrar a negocia��o de cada a��o
 * do mercado.
 */
public class DisplayExchangePrinterImpl extends ExchangePrinterPOA {

  /**
   * O contexto do componente ao qual esta faceta pertence.
   */
  private ComponentContext context;

  /**
   * Construtor
   * 
   * @param context o contexto do componente dono da faceta.
   */
  public DisplayExchangePrinterImpl(ComponentContext context) {
    this.context = context;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void print(String text) {
    System.out.println(text);
  }

  /**
   * Obt�m a faceta IComponent do componente.
   * 
   * @return a faceta IComponent
   */
  public org.omg.CORBA.Object _get_component() {
    return context.getIComponent();
  }

}
