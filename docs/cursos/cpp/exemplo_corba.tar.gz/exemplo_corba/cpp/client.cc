#include <omg/orb.hh>
#include <iostream>
#include "stubs/property.hh"

int main(int argc, char** argv) {
  try {
    CORBA::ORB_var orb = CORBA::ORB_init(argc,argv);
    CORBA::Object_var obj = orb->string_to_object(argv[1]);
    
    Property_var prop = Property::_narrow(obj);
    if (CORBA::is_nil(prop)) {
      std::cerr << "Refer�ncia NULL para o servidor" << std::endl;
      exit(-1);
    }

    std::cout << prop->name() << std::endl << prop->get() << std::endl;
    prop->set(argv[2]);
    std::cout << prop->get() << std::endl;
  }
  catch (const CORBA::Exception& ex) {
     std::cerr << ex << std::endl;
  }

  return 0;
}

